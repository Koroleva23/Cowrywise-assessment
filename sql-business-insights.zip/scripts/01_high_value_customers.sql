-- High-Value Customers with Multiple Products
-- Scenario: The business wants to identify customers who have both a savings and an investment plan (cross-selling opportunity).
-- Task: Write a query to find customers with at least one funded savings plan AND one funded investment plan, sorted by total deposits.
-- Tables: users_customuser, savings_savingsaccount, plans_plan

SELECT 
  a.owner_id,
  b.first_name name,
  COUNT(CASE WHEN c.is_regular_savings = 1 THEN 1 END)  savings_count,
  COUNT(CASE WHEN c.is_a_fund = 1 THEN 1 END)  investment_count,
  SUM(CASE 
        WHEN c.is_regular_savings = 1 OR c.is_a_fund = 1 THEN a.amount 
        ELSE 0 
      END)  total_deposits
FROM 
  adashi_staging.savings_savingsaccount  a
LEFT JOIN 
  adashi_staging.users_customuser b 
  ON (a.owner_id = b.id)
LEFT JOIN 
  adashi_staging.plans_plan c 
  ON (a.plan_id = c.id)
GROUP BY 
  a.owner_id, b.first_name;
