-- Account Inactivity Alert
-- Scenario: The ops team wants to flag accounts with no inflow transactions for over one year.
-- Task: Find all active accounts (savings or investments) with no transactions in the last 1 year (365 days).

SELECT 
    s.plan_id,
    s.owner_id,
    CASE 
        WHEN p.is_regular_savings = 1 THEN 'Savings'
        WHEN p.is_a_fund = 1 THEN 'Investment'
        ELSE 'Unknown'
    END AS type,
    MAX(s.created_on)  last_transaction_date,
    DATEDIFF(CURDATE(), MAX(s.created_on))  inactivity_days
FROM 
    adashi_staging.savings_savingsaccount s
LEFT JOIN 
    adashi_staging.plans_plan p ON s.plan_id = p.id
GROUP BY 
    s.plan_id, s.owner_id, type
HAVING 
    inactivity_days > 365;
