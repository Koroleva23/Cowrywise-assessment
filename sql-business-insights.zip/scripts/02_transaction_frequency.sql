-- Transaction Frequency Analysis
-- Scenario: The finance team wants to analyze how often customers transact to segment them (e.g., frequent vs. occasional users).
-- Task: Calculate the average number of transactions per customer per month and categorize them.

WITH transaction_counts AS (
    SELECT 
        owner_id,
        COUNT(*) AS total_transactions,
        MIN(DATE(created_on)) AS first_tx_date,
        MAX(DATE(created_on)) AS last_tx_date
    FROM adashi_staging.savings_savingsaccount
    GROUP BY owner_id
),

monthly_avg AS (
    SELECT 
        owner_id,
        total_transactions,
        GREATEST(PERIOD_DIFF(DATE_FORMAT(last_tx_date, '%Y%m'), DATE_FORMAT(first_tx_date, '%Y%m')) + 1, 1) AS months_active
    FROM transaction_counts
),

categorized_users AS (
    SELECT 
        owner_id,
        ROUND(total_transactions / months_active, 1) AS avg_tx_per_month,
        CASE 
            WHEN total_transactions / months_active >= 10 THEN 'High Frequency'
            WHEN total_transactions / months_active BETWEEN 3 AND 9 THEN 'Medium Frequency'
            ELSE 'Low Frequency'
        END AS frequency_category
    FROM monthly_avg
)

SELECT 
    frequency_category,
    COUNT(*) AS customer_count,
    ROUND(AVG(avg_tx_per_month), 1) AS avg_transactions_per_month
FROM categorized_users
GROUP BY frequency_category
ORDER BY 
    FIELD(frequency_category, 'High Frequency', 'Medium Frequency', 'Low Frequency');
