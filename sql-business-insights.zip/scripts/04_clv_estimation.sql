-- Customer Lifetime Value (CLV) Estimation
-- Scenario: Marketing wants to estimate CLV based on account tenure and transaction volume (simplified model).
-- Task: For each customer, assuming the profit_per_transaction is 0.1% of the transaction value, calculate:
-- Account tenure (months since signup)
-- Total transactions
-- Estimated CLV

SELECT 
    A.id AS customer_id,
    CONCAT(A.first_name, ' ', A.last_name) AS name,
    GREATEST(PERIOD_DIFF(DATE_FORMAT(CURDATE(), '%Y%m'), DATE_FORMAT(A.date_joined, '%Y%m')), 1) AS tenure_months,
    COUNT(B.id) AS total_transactions,
    ROUND(
        (COUNT(B.id) / GREATEST(PERIOD_DIFF(DATE_FORMAT(CURDATE(), '%Y%m'), DATE_FORMAT(A.date_joined, '%Y%m')), 1)) 
        * 12 
        * (0.001 * AVG(B.amount)),
        2
    ) AS estimated_clv
FROM 
    adashi_staging.users_customuser A
LEFT JOIN 
    adashi_staging.savings_savingsaccount B ON A.id = B.owner_id
GROUP BY 
    A.id, name
ORDER BY 
    estimated_clv DESC;
